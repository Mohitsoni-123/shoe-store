import "dotenv/config";
import { v2 as cloudinary } from "cloudinary";

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

console.log(
  "Cloud Name:",
  process.env.CLOUDINARY_CLOUD_NAME
);

console.log(
  "API Key Loaded:",
  !!process.env.CLOUDINARY_API_KEY
);

console.log(
  "API Secret Loaded:",
  !!process.env.CLOUDINARY_API_SECRET
);


export default cloudinary;